-- ================================================
-- 기말 프로젝트
-- 이름 : 정석호
-- 학번 : 2544408
-- ================================================


-- ================================================
-- 1. CREATE TABLE
-- ================================================


create table customer (
                          cus_id  varchar(15)    primary key,
                          name    varchar(20)    not null,
                          cell    char(13)       not null unique,
                          addr    varchar(100),
                          c_code  int            default 3
);

create table staff (
                       staff_id    int         primary key,
                       name        varchar(20) not null,
                       birthday    char(6)     not null,
                       tel         char(12),
                       salary      int,
                       t_code      int         not null,
                       hire_date   char(8)     not null
);

create table tour (
                      tour_num    char(8)     primary key,
                      departure   varchar(50) not null,
                      arrival     varchar(50) not null,
                      program     varchar(100),
                      start_dt    date        not null,
                      end_dt      date        not null,
                      min_num     int,
                      max_num     int,
                      expense     int      not null,
                      deposit     int,
                      dept_yn     char(1)     default 'N',
                      staff_id    int,
                      foreign key (staff_id) references staff(staff_id)
);

create table reserve (
                         cus_id      varchar(15) not null,
                         tour_num    char(8)     not null,
                         res_date    char(8)     default to_char(current_date, 'YYYYMMDD'),
                         dep_yn      char(1)     default 'N',
                         exp_yn      char(1)     default 'N',
                         primary key (cus_id, tour_num),
                         foreign key (cus_id)     references customer(cus_id),
                         foreign key (tour_num)   references tour(tour_num)
);

create table class_code (
                            code    int            primary key,
                            class   varchar(10),
                            basis   varchar(20)
);

create table task_code (
                           code    int            primary key,
                           task    varchar(30)
);


-- ================================================
-- 보너스 테이블
-- ================================================

create table driver (
                        driver_id   int         primary key,
                        name        varchar(20) not null,
                        birthday    char(6)     not null,
                        cell        char(13)    not null,
                        pay         int         default 15000,
                        cont_date   char(8),
                        cont_term   char(8)
);

create table tour_bus (
                          bus_id      int         primary key,
                          seat        int,
                          del_year    int
);

create table assign_driver (
                               tour_num    char(8)     not null,
                               driver_id   int,
                               work_hour   int,
                               primary key (tour_num),
                               foreign key (tour_num)   references tour(tour_num),
                               foreign key (driver_id)  references driver(driver_id)
);

create table assign_bus (
                            tour_num    char(8)     not null,
                            bus_id      int,
                            primary key (tour_num),
                            foreign key (tour_num)   references tour(tour_num),
                            foreign key (bus_id)     references tour_bus(bus_id)
);


-- ================================================
-- 2. INSERT DATA
-- ================================================


-- 고객
insert into customer values
                         ('cus001', '홍길동', '010-1111-2222', '서울시 강남구', 1),
                         ('cus002', '김민지', '010-2222-3333', '부산시 해운대구', 2),
                         ('cus003', '이준혁', '010-3333-4444', '대구시 수성구', 3),
                         ('cus004', '박소연', '010-4444-5555', '인천시 연수구', 2),
                         ('cus005', '최동현', '010-5555-6666', '광주시 북구', 3);


insert into staff values
                      (10001, '김지훈', '850312', '043-123-4567', 4200000, 1, '20180301'),
                      (10002, '이수진', '900721', '043-234-5678', 3800000, 2, '20200615'),
                      (10003, '박철민', '880115', '043-345-6789', 4500000, 3, '20160901'),
                      (10004, '최미영', '921030', '043-456-7890', 3500000, 5, '20211201'),
                      (10005, '정현우', '870518', '043-567-8901', 5000000, 4, '20140401');

-- 여행상품
insert into tour values
                     ('T2026001', '서울', '부산', 'https://tour.kr/busan',    '2026-07-01', '2026-07-03', 10, 40, 450000, 100000, 'Y', 10001),
                     ('T2026002', '서울', '제주', 'https://tour.kr/jeju',     '2026-07-10', '2026-07-13',  8, 30, 780000, 200000, 'Y', 10002),
                     ('T2026003', '대전', '강릉', 'https://tour.kr/gangneung', '2026-08-05', '2026-08-07', 12, 35, 390000,  80000, 'N', 10003),
                     ('T2026004', '부산', '경주', 'https://tour.kr/gyeongju', '2026-08-15', '2026-08-16', 15, 45, 320000,  70000, 'Y', 10001),
                     ('T2026005', '서울', '전주', 'https://tour.kr/jeonju',   '2026-09-01', '2026-09-02',  6, 25, 250000,  50000, 'N', 10004);

-- 예약
insert into reserve values
                        ('cus001', 'T2026001', '20260601', 'Y', 'N'),
                        ('cus002', 'T2026001', '20260602', 'Y', 'Y'),
                        ('cus003', 'T2026002', '20260605', 'N', 'N'),
                        ('cus004', 'T2026003', '20260607', 'Y', 'N'),
                        ('cus005', 'T2026004', '20260610', 'N', 'N');
-- 고객등급코드
insert into class_code values
                           (1, '최우수', '누적금액 500만원 이상'),
                           (2, '우수',   '누적금액 100만원 이상'),
                           (3, '일반',   '누적금액 100만원 미만');

-- 업무코드
insert into task_code values
                          (1, '여행상품관리'),
                          (2, '예약관리'),
                          (3, '관광버스배차관리'),
                          (4, '직원관리'),
                          (5, '고객관리');

-- ================================================

-- 운전기사
insert into driver values
                       (20001, '강태풍', '830422', '010-6111-1111', 18000, '20230401', '24'),
                       (20002, '윤성민', '870910', '010-6222-2222', 15000, '20240101', '12'),
                       (20003, '임도현', '910205', '010-6333-3333', 16000, '20220701', '36'),
                       (20004, '조한솔', '860318', '010-6444-4444', 17000, '20231001', '18'),
                       (20005, '신재원', '920815', '010-6555-5555', 15000, '20250301', '12');

-- 관광버스
insert into tour_bus values
                         (1, 45, 2020),
                         (2, 28, 2019),
                         (3, 45, 2022),
                         (4, 28, 2021),
                         (5, 45, 2023);

-- 기사 배정
insert into assign_driver values
                              ('T2026001', 20001, 6),
                              ('T2026002', 20002, 9),
                              ('T2026003', 20003, 4),
                              ('T2026004', 20004, 3),
                              ('T2026005', 20005, 5);

-- 버스 배정
insert into assign_bus values
                           ('T2026001', 1),
                           ('T2026002', 3),
                           ('T2026003', 2),
                           ('T2026004', 5),
                           ('T2026005', 4);


-- ================================================
-- 3. INDEX 생성
-- ================================================


create index tour_arrival_idx  on tour(arrival);
create index driver_name_idx   on driver(name);

-- 추가 인덱스 (검색 빈도 높은 컬럼)
create index idx_customer_name on customer(name);
create index idx_reserve_tour  on reserve(tour_num);


-- ================================================
-- 4. 테스트 7가지
-- ================================================

-- 1. 고객 등급 검색하기
-- 입력한 id를 갖는 고객의 이름과 등급을 검색
select
    c.name,
    cc.class
from customer c
         join class_code cc on c.c_code = cc.code
where c.cus_id = 'cus001';


-- 2. 직원 담당업무 검색하기
-- 입력한 사번을 갖는 직원의 이름과 담당업무를 검색
select
    s.name,
    t.task
from staff s
         join task_code t on s.t_code = t.code
where s.staff_id = 10001;


-- 3. 여행상품 예약 고객 검색하기
-- 입력한 여행번호를 예약한 모든 고객의 이름, 예약일자, 예약금결제여부 검색
select
    c.name,
    r.res_date,
    r.dep_yn
from reserve r
         join customer c on r.cus_id = c.cus_id
where r.tour_num = 'T2026001';


-- 4. 여행상품에 배정된 운전기사 검색하기
-- 입력한 여행번호의 출발지, 배정된 운전기사 이름, 휴대폰번호 검색
select
    t.departure,
    d.name,
    d.cell
from tour t
         join assign_driver ad on t.tour_num = ad.tour_num
         join driver d         on ad.driver_id = d.driver_id
where t.tour_num = 'T2026001';


-- 5. 신규 고객 데이터 삽입하기
-- 새로운 고객의 id, 이름, 휴대폰 정보를 삽입
insert into customer (cus_id, name, cell)
values ('cus006', '테스트고객', '010-9999-0000');


-- 6. 직원 급여 변경하기
-- 입력한 사번을 갖는 직원의 급여를 20만원 증가
update staff
set salary = salary + 200000
where staff_id = 10001;


-- 7. 예약 정보 삭제하기
-- 입력한 고객 id와 여행번호를 갖는 예약 정보 삭제
delete from reserve
where cus_id = 'cus006'
  and tour_num = 'T2026001';


-- ================================================
-- 5. 결과 확인
-- ================================================


table customer;
table staff;
table tour;
table reserve;
table class_code;
table task_code;
table driver;
table tour_bus;
table assign_driver;
table assign_bus;



